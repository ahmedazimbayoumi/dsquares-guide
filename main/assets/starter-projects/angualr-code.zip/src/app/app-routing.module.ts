import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './components/home/home.component';
import { PointsHistoryComponent } from './components/points-history/points-history.component';
import { PartnersComponent } from './components/partners/partners.component';
import { VouchersComponent } from './components/vouchers/vouchers.component';
import { OfferDetailsComponent } from './components/offer-details/offer-details.component';
import { AboutComponent } from './components/about/about.component';
import { LoginComponent } from './components/login/login.component';

const routes: Routes = [

  {
    path: '',
    component: HomeComponent,
  },
  {
    path: 'history',
    component: PointsHistoryComponent,
  },
  {
    path: 'partners',
    component: PartnersComponent,
  },
  {
    path: 'vouchers',
    component: VouchersComponent,
  },
  {
    path: 'offerDetails',
    component: OfferDetailsComponent,
  },
  {
    path: 'about',
    component: AboutComponent,
  },
  {
    path: 'login',
    component: LoginComponent,
  },

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
