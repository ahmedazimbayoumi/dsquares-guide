import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-points-history',
  templateUrl: './points-history.component.html',
  styleUrls: ['./points-history.component.scss']
})
export class PointsHistoryComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

  active = 1;
  public isCollapsed = true;
  public isCollapsed2 = true;
  public isCollapsed3 = true;
  public isCollapsed4 = true;
  public isCollapsed5 = true;
  public isCollapsed6 = true;
}
