import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-vouchers',
  templateUrl: './vouchers.component.html',
  styleUrls: ['./vouchers.component.scss']
})
export class VouchersComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

  active = 1;
  public isCollapsed = false;
  public isCollapsed2 = false;
  public isCollapsed3 = false;

}
