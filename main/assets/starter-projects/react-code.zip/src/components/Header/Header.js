import React from 'react';
import Navbar from 'react-bootstrap/Navbar';
import Nav from 'react-bootstrap/Nav';
import Container from 'react-bootstrap/Container';
import logo from'./../../assets/img/logo.png';
import './Header.scss';

const Header = () => (
  
  <Navbar expand="md" variant="dark">
    <Container>
      <Navbar.Brand href="/">
          <img  src={logo} alt="Moe logo"/>
      </Navbar.Brand>
      <Navbar.Toggle aria-controls="basic-navbar-nav" />
      <Navbar.Collapse id="basic-navbar-nav">
        <Nav className="me-auto flex-1 w-100">
          <div className='flex-2'>
              <Nav.Link href="/">الرئيسية</Nav.Link>
              <Nav.Link href="/about">عن البرنامج</Nav.Link>
          </div>
          <div className='flex-2'>
              <Nav.Link href="/"><i className="fa-solid fa-arrow-right-to-bracket me-1"></i>  تسجيل الخروج</Nav.Link>
              <Nav.Link href="/">ENG</Nav.Link>
          </div>
        </Nav>
      </Navbar.Collapse>
    </Container>
  </Navbar>

)
export default Header;