import React, { useState } from "react";
import "./Home.scss";
import historyImg from "./../../assets/img/history.svg";
import partnersImg from "./../../assets/img/partners.svg";
import vouchersImg from "./../../assets/img/vouchers.svg";
import Modal from 'react-bootstrap/Modal';
import Button from 'react-bootstrap/Button';
import Form from 'react-bootstrap/Form';
import OTPInput, { ResendOTP } from "otp-input-react";





function Home() {

    const [show, setShow] = useState(true);
    const [show2, setShow2] = useState(false);
  
    const closePhoneNum = () => setShow(false);
    // const showPhoneNum = () => setShow(true);

    const closeOTP = () => setShow2(false);
    const showOTP = () => [setShow2(true), setShow(false)];

    const [OTP, setOTP] = useState("");
    const renderButton = (buttonProps) => {
        return <span className="underline text-muted h7 mt-3 fw-bold" {...buttonProps}>إرسال الكود مرة آخري</span>;
      };

      const renderTime = (remainingTime) => {
        return <span className="mt-4 text-muted h7"> سيتم إرسال الكود بعد {remainingTime} ثانية </span>;
      };
    
  
    return (

      <>

        <div className="container home">
          <h1 className="text-center mt-44 fw-bold display-5 color-1">
            Abdelrahman Ahmed
          </h1>
          <div className="row mt-5 mb-55 home-icons">
            <div className="col-md-4 text-center">
              <div className="card p-5 px-4 bg-1 border-0 rounded-4">
                <a href="/vouchers">
                  <img
                    className="mb-4 mt-2"
                    height={130}
                    src={vouchersImg}
                    alt="Moe logo"
                  />
                  <span className="d-block h4 mb-0"> قسائم الشراء </span>
                </a>
              </div>
            </div>
            <div className="col-md-4 text-center">
              <div className="card p-5 px-4 bg-1 border-0 rounded-4">
                <a href="/partners">
                  <img
                    className="mb-4 mt-2"
                    height={130}
                    src={partnersImg}
                    alt="Moe logo"
                  />
                  <span className="d-block h4 mb-0"> قائمة الشركاء </span>
                </a>
              </div>
            </div>
            <div className="col-md-4 text-center">
              <div className="card p-5 px-4 bg-1 border-0 rounded-4">
                <a href="/history">
                  <img
                    className="mb-4 mt-2"
                    height={130}
                    src={historyImg}
                    alt="Moe logo"
                  />
                  <span className="d-block h4 mb-0"> تاريخ قسائم الشراء </span>
                </a>
              </div>
            </div>
          </div>
        </div>


        {/* mobile number modal */}
        <Modal  show={show} centered onHide={closePhoneNum} className="modal-1">
          <Modal.Header className="border-0 pt-4" closeButton>
            <Modal.Title className="fw-bold ps-4 mt-3">يرجى إدخال رقم الموبايل</Modal.Title>
          </Modal.Header>
          <Modal.Body className="">

                <Form.Label className="mb-0 text-muted" htmlFor="inputPassword5">رقم الموبايل</Form.Label>
                <Form.Control className="border-0 px-0 text-info"
                    type="text"
                    id="inputPassword5"
                    aria-describedby="passwordHelpBlock"
                    placeholder="0101 234 56 789"
                />
 

          </Modal.Body>
          <Modal.Footer className="border-0 text-center d-block">
            <Button className="text-light mb-3" variant="info" onClick={showOTP}>
                 حفظ
            </Button>
          </Modal.Footer>
        </Modal>

        {/* otp modal */}
        <Modal dialogClassName="modal-90w" show={show2} centered onHide={closeOTP} className="modal-2">
          <Modal.Header className="border-0 pb-0 pt-4" closeButton>
            <Modal.Title className="fw-bold mt-3"> من فضلك قم بإدخال كود التحقق </Modal.Title>
          
          </Modal.Header>
          <Modal.Body className="pt-1">
          <p className="mb-4 text-muted h7">لقد قمنا بإرسال كود تحقق إلي هاتفك علي رقم 0101 234 56 789</p>

          <div>
            <OTPInput  className="otp-section" value={OTP} onChange={setOTP} autoFocus OTPLength={6} otpType="number" disabled={false}  />
            <ResendOTP renderButton={renderButton} className="resend-otp" renderTime={renderTime} onResendClick={() => console.log("Resend clicked")} />
            <a className="text-info underline mt-3 d-block h7 fw-bold" href="/">تغيير رقم الهاتف</a>
          </div>


          </Modal.Body>
          <Modal.Footer className="border-0 text-center d-block">
            <Button className="text-light mb-3" variant="info" onClick={closePhoneNum}>
            تحقق
            </Button>
          </Modal.Footer>
        </Modal>


        {/* <Button variant="primary" onClick={showOTP}>
          Launch demo modal2
        </Button> */}
        

        {/* <Button variant="primary" onClick={showPhoneNum}>
          Launch demo modal1
        </Button> */}

        

      </>

    );

  }
  
 

  export default Home;

