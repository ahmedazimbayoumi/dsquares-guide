import React from "react";
import "./History.scss";
import Table from 'react-bootstrap/Table';
import Pagination from 'react-bootstrap/Pagination';

const History = () => (
    
  <>

  <div className="container-fluid mb-4 mt-5">

  <h2 className="display-6 heading text-info fw-normal mb-5">
  <i className="fa-solid fa-arrow-right me-2"></i> تاريخ قسائم الشراء 
    </h2>

    <Table striped  hover>
  <thead>
    <tr>
      <th>قسيمة الشراء</th>
      <th>تاريخ الانتهاء</th>
      <th>كود القسيمة</th>
      <th>حالة القسيمة</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>تفاصيل القسيمة</td>
      <td>10 اكتوبر</td>
      <td> <span className="red fw-bold">1234567890</span> </td>
      <td> <span className="green">لم تستخدم بعد</span> </td>
    </tr>
    <tr>
      <td>تفاصيل القسيمة</td>
      <td>10 اكتوبر</td>
      <td> <span className="red fw-bold">1234567890</span> </td>
      <td> <span className="">مستخدمة</span> </td>
    </tr>
    <tr>
      <td>تفاصيل القسيمة</td>
      <td>10 اكتوبر</td>
      <td> <span className="red fw-bold">1234567890</span> </td>
      <td> <span className="light-red">منتهي الصلاحية</span> </td>
    </tr>
    <tr>
      <td>تفاصيل القسيمة</td>
      <td>10 اكتوبر</td>
      <td> <span className="red fw-bold">1234567890</span> </td>
      <td> <span className="green">لم تستخدم بعد</span> </td>
    </tr>
    <tr>
      <td>تفاصيل القسيمة</td>
      <td>10 اكتوبر</td>
      <td> <span className="red fw-bold">1234567890</span> </td>
      <td> <span className="">مستخدمة</span> </td>
    </tr>
    <tr>
      <td>تفاصيل القسيمة</td>
      <td>10 اكتوبر</td>
      <td> <span className="red fw-bold">1234567890</span> </td>
      <td> <span className="light-red">منتهي الصلاحية</span> </td>
    </tr>
  </tbody>
</Table>

<div >
  <Pagination className="justify-content-center mt-4 mb-5">
    <Pagination.Prev className="nav-item next" />
    <Pagination.Item>{1}</Pagination.Item>
    <Pagination.Item>{2}</Pagination.Item>
    <Pagination.Item>{3}</Pagination.Item>
    <Pagination.Item active>{4}</Pagination.Item>
    <Pagination.Item>{5}</Pagination.Item>
    <Pagination.Ellipsis />
    <Pagination.Item>{10}</Pagination.Item>
    <Pagination.Next className="nav-item prev" />
  </Pagination>
</div>
  </div>

  


</>
  
);
export default History;
