import React from "react";
import "./Partners.scss";
import merchantImg from "./../../assets/img/sample-merchant.png";

const Vouchers = () => (
    
  <>

    <div className="container-fluid mb-4 mt-5">
    <div className="header-filters">
      <h2 className="display-6 heading text-info fw-normal">
            {" "}
            <i className="fa-solid fa-arrow-right me-2"></i>  قائمة الشركاء {" "}
        </h2>
      <div className="filters">
        <span className="active"> عرض الكل </span>
        <span> أغذية ومشروبات </span>
        <span> بقالة </span>
        <span> ازياء </span>
        <span> هدايا واكسسوارات </span>
        <span> صحة وجمال </span>
        <span> الكترونيات </span>
        <span> فنادق وسفر </span>
        <span> اونلاين </span>
      </div>
    </div>
    </div>

    <div className="cards mb-5">

        <div className="card p-3 mb-3 shadow">
              <img
                className="mb-4 mt-3 merchant-logo"
                src={merchantImg}
                alt="Moe logo"
              />
              <div className="text-center">
                <h3 className="h6 fw-bold mb-3">كوك دوور</h3>
            </div>
        
        </div>

        <div className="card p-3 mb-3 shadow">
              <img
                className="mb-4 mt-3 merchant-logo"
                src={merchantImg}
                alt="Moe logo"
              />
              <div className="text-center">
                <h3 className="h6 fw-bold mb-3">كوك دوور</h3>
            </div>
        
        </div>

        <div className="card p-3 mb-3 shadow">
              <img
                className="mb-4 mt-3 merchant-logo"
                src={merchantImg}
                alt="Moe logo"
              />
              <div className="text-center">
                <h3 className="h6 fw-bold mb-3">كوك دوور</h3>
            </div>
        
        </div>

        <div className="card p-3 mb-3 shadow">
              <img
                className="mb-4 mt-3 merchant-logo"
                src={merchantImg}
                alt="Moe logo"
              />
              <div className="text-center">
                <h3 className="h6 fw-bold mb-3">كوك دوور</h3>
            </div>
        
        </div>

        <div className="card p-3 mb-3 shadow">
              <img
                className="mb-4 mt-3 merchant-logo"
                src={merchantImg}
                alt="Moe logo"
              />
              <div className="text-center">
                <h3 className="h6 fw-bold mb-3">كوك دوور</h3>
            </div>
        
        </div>

        <div className="card p-3 mb-3 shadow">
              <img
                className="mb-4 mt-3 merchant-logo"
                src={merchantImg}
                alt="Moe logo"
              />
              <div className="text-center">
                <h3 className="h6 fw-bold mb-3">كوك دوور</h3>
            </div>
        
        </div>

        <div className="card p-3 mb-3 shadow">
              <img
                className="mb-4 mt-3 merchant-logo"
                src={merchantImg}
                alt="Moe logo"
              />
              <div className="text-center">
                <h3 className="h6 fw-bold mb-3">كوك دوور</h3>
            </div>
        
        </div>

        <div className="card p-3 mb-3 shadow">
              <img
                className="mb-4 mt-3 merchant-logo"
                src={merchantImg}
                alt="Moe logo"
              />
              <div className="text-center">
                <h3 className="h6 fw-bold mb-3">كوك دوور</h3>
            </div>
        
        </div>

        <div className="card p-3 mb-3 shadow">
              <img
                className="mb-4 mt-3 merchant-logo"
                src={merchantImg}
                alt="Moe logo"
              />
              <div className="text-center">
                <h3 className="h6 fw-bold mb-3">كوك دوور</h3>
            </div>
        
        </div>

        <div className="card p-3 mb-3 shadow">
              <img
                className="mb-4 mt-3 merchant-logo"
                src={merchantImg}
                alt="Moe logo"
              />
              <div className="text-center">
                <h3 className="h6 fw-bold mb-3">كوك دوور</h3>
            </div>
        
        </div>

        <div className="card p-3 mb-3 shadow">
              <img
                className="mb-4 mt-3 merchant-logo"
                src={merchantImg}
                alt="Moe logo"
              />
              <div className="text-center">
                <h3 className="h6 fw-bold mb-3">كوك دوور</h3>
            </div>
        
        </div>

        <div className="card p-3 mb-3 shadow">
              <img
                className="mb-4 mt-3 merchant-logo"
                src={merchantImg}
                alt="Moe logo"
              />
              <div className="text-center">
                <h3 className="h6 fw-bold mb-3">كوك دوور</h3>
            </div>
        
        </div>

        <div className="card p-3 mb-3 shadow">
              <img
                className="mb-4 mt-3 merchant-logo"
                src={merchantImg}
                alt="Moe logo"
              />
              <div className="text-center">
                <h3 className="h6 fw-bold mb-3">كوك دوور</h3>
            </div>
        
        </div>

        <div className="card p-3 mb-3 shadow">
              <img
                className="mb-4 mt-3 merchant-logo"
                src={merchantImg}
                alt="Moe logo"
              />
              <div className="text-center">
                <h3 className="h6 fw-bold mb-3">كوك دوور</h3>
            </div>
        
        </div>


    </div>


</>
  
);
export default Vouchers;
