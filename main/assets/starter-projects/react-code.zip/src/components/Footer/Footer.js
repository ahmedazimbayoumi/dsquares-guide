import React from 'react';
import './Footer.scss';
import logo from'./../../assets/img/logo.png';

const Footer = () => (
  <div className="footer">
       <img height={50} className="pe-3" src={logo} alt="Moe logo"/>  جميع الحقوق محفوظة © 2021
  </div>
)
export default Footer;