import React, { useState } from "react";
import "./Vouchers.scss";
import discountImg from "./../../assets/img/discount.svg";
import merchantImg from "./../../assets/img/sample-merchant.png";
import voucherImg from "./../../assets/img/voucher-icon.svg";
import { Swiper, SwiperSlide } from "swiper/react";
import { FreeMode } from "swiper";
import "swiper/css";
import "swiper/css/pagination";
import Modal from 'react-bootstrap/Modal';
import Button from 'react-bootstrap/Button';

function Vouchers() {

  const [show, setShow] = useState(false);

  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);

    return (

      <>

        <div className="container-fluid mb-4 mt-5">
        <div className="header-filters">
          <h2 className="display-6 heading text-info fw-normal">
            {" "}
            <i className="fa-solid fa-arrow-right me-2"></i> قسائم الشراء{" "}
          </h2>
          <div className="filters">
            <span className="active"> عرض الكل </span>
            <span> أغذية ومشروبات </span>
            <span> بقالة </span>
            <span> ازياء </span>
            <span> هدايا واكسسوارات </span>
            <span> صحة وجمال </span>
            <span> الكترونيات </span>
            <span> فنادق وسفر </span>
            <span> اونلاين </span>
          </div>
        </div>
        </div>

        <Swiper
          freeMode={true}
          pagination={{
            clickable: true
          }}
          breakpoints={{
            320: {
              slidesPerView: 1,
              spaceBetween: 20,
            },
            480: {
              slidesPerView: 2,
              spaceBetween: 20,
            },
            640: {
              slidesPerView: 3,
              spaceBetween: 20,
            },
            768: {
              slidesPerView: 4,
              spaceBetween: 20,
            },
            1024: {
              slidesPerView: 5,
              spaceBetween: 20,
            },
          }}
          modules={[FreeMode]}
          className="mySwiper cards"
        >
          <SwiperSlide>
            <div className="card p-3">
              <div className="text-start">
                <img className="" height={40} src={discountImg} alt="Moe logo" />
              </div>
              <img
                className="mb-4 mt-3 merchant-logo"
                src={merchantImg}
                alt="Moe logo"
              />
              <div className="text-center">
                <h3 className="h4 fw-bold">كوك دوور</h3>
                <p className="h8 text-muted mb-2">خصم بقيمة 15% على الفاتورة</p>
              </div>
              <button onClick={handleShow} type="button" className="btn btn-info text-white">
                احصل على العرض
              </button>
            </div>
          </SwiperSlide>
          <SwiperSlide>
            <div className="card p-3">
              <div className="text-start">
                <img className="" height={40} src={discountImg} alt="Moe logo" />
              </div>
              <img
                className="mb-4 mt-3 merchant-logo"
                src={merchantImg}
                alt="Moe logo"
              />
              <div className="text-center">
                <h3 className="h4 fw-bold">كوك دوور</h3>
                <p className="text-muted h8 mb-2">خصم بقيمة 15% على الفاتورة</p>
              </div>
              <button onClick={handleShow} type="button" className="btn btn-info text-white">
                احصل على العرض
              </button>
            </div>
          </SwiperSlide>
          <SwiperSlide>
            <div className="card p-3">
              <div className="text-start">
                <img className="" height={40} src={discountImg} alt="Moe logo" />
              </div>
              <img
                className="mb-4 mt-3 merchant-logo"
                src={merchantImg}
                alt="Moe logo"
              />
              <div className="text-center">
                <h3 className="h4 fw-bold">كوك دوور</h3>
                <p className="text-muted h8 mb-2">خصم بقيمة 15% على الفاتورة</p>
              </div>
              <button onClick={handleShow} type="button" className="btn btn-info text-white">
                احصل على العرض
              </button>
            </div>
          </SwiperSlide>
          <SwiperSlide>
            <div className="card p-3">
              <div className="text-start">
                <img className="" height={40} src={discountImg} alt="Moe logo" />
              </div>
              <img
                className="mb-4 mt-3 merchant-logo"
                src={merchantImg}
                alt="Moe logo"
              />
              <div className="text-center">
                <h3 className="h4 fw-bold">كوك دوور</h3>
                <p className="text-muted h8 mb-2">خصم بقيمة 15% على الفاتورة</p>
              </div>
              <button onClick={handleShow} type="button" className="btn btn-info text-white">
                احصل على العرض
              </button>
            </div>
          </SwiperSlide>
          <SwiperSlide>
            <div className="card p-3">
              <div className="text-start">
                <img className="" height={40} src={discountImg} alt="Moe logo" />
              </div>
              <img
                className="mb-4 mt-3 merchant-logo"
                src={merchantImg}
                alt="Moe logo"
              />
              <div className="text-center">
                <h3 className="h4 fw-bold">كوك دوور</h3>
                <p className="text-muted h8 mb-2">خصم بقيمة 15% على الفاتورة</p>
              </div>
              <button onClick={handleShow} type="button" className="btn btn-info text-white">
                احصل على العرض
              </button>
            </div>
          </SwiperSlide>
          <SwiperSlide>
            <div className="card p-3">
              <div className="text-start">
                <img className="" height={40} src={discountImg} alt="Moe logo" />
              </div>
              <img
                className="mb-4 mt-3 merchant-logo"
                src={merchantImg}
                alt="Moe logo"
              />
              <div className="text-center">
                <h3 className="h4 fw-bold">كوك دوور</h3>
                <p className="text-muted h8 mb-2">خصم بقيمة 15% على الفاتورة</p>
              </div>
              <button onClick={handleShow} type="button" className="btn btn-info text-white">
                احصل على العرض
              </button>
            </div>
          </SwiperSlide>
          <SwiperSlide>
            <div className="card p-3">
              <div className="text-start">
                <img className="" height={40} src={discountImg} alt="Moe logo" />
              </div>
              <img
                className="mb-4 mt-3 merchant-logo"
                src={merchantImg}
                alt="Moe logo"
              />
              <div className="text-center">
                <h3 className="h4 fw-bold">كوك دوور</h3>
                <p className="text-muted h8 mb-2">خصم بقيمة 15% على الفاتورة</p>
              </div>
              <button onClick={handleShow} type="button" className="btn btn-info text-white">
                احصل على العرض
              </button>
            </div>
          </SwiperSlide>
          <SwiperSlide>
            <div className="card p-3">
              <div className="text-start">
                <img className="" height={40} src={discountImg} alt="Moe logo" />
              </div>
              <img
                className="mb-4 mt-3 merchant-logo"
                src={merchantImg}
                alt="Moe logo"
              />
              <div className="text-center">
                <h3 className="h4 fw-bold">كوك دوور</h3>
                <p className="text-muted h8 mb-2">خصم بقيمة 15% على الفاتورة</p>
              </div>
              <button onClick={handleShow} type="button" className="btn btn-info text-white">
                احصل على العرض
              </button>
            </div>
          </SwiperSlide>
          <SwiperSlide>
            <div className="card p-3">
              <div className="text-start">
                <img className="" height={40} src={discountImg} alt="Moe logo" />
              </div>
              <img
                className="mb-4 mt-3 merchant-logo"
                src={merchantImg}
                alt="Moe logo"
              />
              <div className="text-center">
                <h3 className="h4 fw-bold">كوك دوور</h3>
                <p className="text-muted h8 mb-2">خصم بقيمة 15% على الفاتورة</p>
              </div>
              <button onClick={handleShow} type="button" className="btn btn-info text-white">
                احصل على العرض
              </button>
            </div>
          </SwiperSlide>
        </Swiper>



      <Modal centered show={show} onHide={handleClose} className="modal-3">
        <Modal.Header  className="border-0 pt-4" closeButton>
          
        </Modal.Header>
        <Modal.Body className="text-center">
           <div className="top">
                <img className="mb-3" height={150} src={voucherImg} alt="Moe logo" />
                <h3 className="h5 fw-bold mb-3">خصم 15% من كوك دور</h3>
                <div className="code mb-3">1417672</div>
                <p className="h7 text-muted">ينتهي في الاثنين 21 اكتوبر 2022</p>
           </div>
           <div className="bottom">
                <p className="mb-4 h7">برجاء استخدام الكود قبل تاريخ الانتهاء</p>
                <Button className="mb-2 text-white" variant="info" onClick={handleClose}>
                شركاؤنا
                </Button>
                <Button variant="outline-info" onClick={handleClose}>
                إنهاء
                </Button>
           </div>
        </Modal.Body>
      </Modal>

      </>

      );


}

export default Vouchers;
