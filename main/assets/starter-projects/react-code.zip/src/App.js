import "./sass/main.scss";
import Header from "./components/Header/Header";
import Footer from "./components/Footer/Footer";
import Home from "./components/Home/Home";
import About from "./components/About/About";
import Vouchers from "./components/Vouchers/Vouchers";
import Partners from "./components/Partners/Partners";
import History from "./components/History/History";

import {
  BrowserRouter,
  Routes,
  Route
} from "react-router-dom";

function App() {
  return (
    <div className="App h-100">
      <Header />
      <BrowserRouter>
        <Routes className="min-container">
          <Route path="/" element={<Home />} />
          <Route path="/about" element={<About />} />
          <Route path="/vouchers" element={<Vouchers />} />
          <Route path="/partners" element={<Partners />} />
          <Route path="/history" element={<History />} />
        </Routes>
      </BrowserRouter>
      
      <Footer />
    </div>
  );
}

export default App;
